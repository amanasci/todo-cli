This is a todo cli made with nodejs. 

## To make system link:

> ### Windows:
> mklink todo todo.bat

> ### Linux:
> ln -s todo.sh todo


## Known issues:
1. For some reasons tests are not working on linux devices. 
2. Code isn't optimized
3. There can be unknown bugs